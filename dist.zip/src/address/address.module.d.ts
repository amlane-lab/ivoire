export declare class AddressModule {
}
