export declare class BannerModule {
}
