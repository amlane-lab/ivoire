export declare class BusinessModule {
}
