export declare class CartModule {
}
