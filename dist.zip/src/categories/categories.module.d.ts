export declare class CategoryModule {
}
