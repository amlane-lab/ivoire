export declare class ChatModule {
}
