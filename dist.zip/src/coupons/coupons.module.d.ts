export declare class CouponsModule {
}
