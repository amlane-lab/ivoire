export declare class DealModule {
}
