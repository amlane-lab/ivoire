export declare class DeliveryBoyRatingsModule {
}
