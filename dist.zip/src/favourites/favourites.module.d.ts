export declare class FavouritesModule {
}
