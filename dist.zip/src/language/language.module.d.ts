export declare class LanguageModule {
}
