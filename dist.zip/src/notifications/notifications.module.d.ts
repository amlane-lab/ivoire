export declare class NotificationsModule {
}
