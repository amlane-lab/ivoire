export declare class OrderModule {
}
