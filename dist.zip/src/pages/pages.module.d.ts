export declare class PageModule {
}
