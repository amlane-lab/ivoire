export declare class ProductOutOfStockModule {
}
