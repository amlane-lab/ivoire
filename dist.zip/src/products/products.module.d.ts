export declare class ProductModule {
}
