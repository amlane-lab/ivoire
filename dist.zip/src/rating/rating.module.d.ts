export declare class RatingModule {
}
