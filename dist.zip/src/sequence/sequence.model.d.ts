import * as mongoose from 'mongoose';
export declare const SequenceSchema: mongoose.Schema<any>;
