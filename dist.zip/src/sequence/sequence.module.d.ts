export declare class SequenceModule {
}
