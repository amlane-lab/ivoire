export declare class SettingModule {
}
