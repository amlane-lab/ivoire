export declare class SubCategoryModule {
}
