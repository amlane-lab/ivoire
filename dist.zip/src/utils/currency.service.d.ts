export declare class CurrencyService {
    constructor();
    getAllCurrencyList(): any;
}
