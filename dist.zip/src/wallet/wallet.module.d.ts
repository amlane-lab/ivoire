export declare class WalletModule {
}
